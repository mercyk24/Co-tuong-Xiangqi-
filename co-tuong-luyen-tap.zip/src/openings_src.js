// Nguồn bài khai cuộc: Bình phong mã (屏風馬) đối Pháo đầu (中炮). Người học chơi bên Đen.
// Chuỗi nước đi lấy từ các tài liệu lý thuyết công khai (xem README); phần giải thích do mình viết lại bằng tiếng Việt.
const TRUNK_A = '炮二平五 馬8進7 傌二進三 車9平8 車一平二 卒7進1 車二進六 馬2進3 兵七進一 炮8平9 車二平三 炮9退1';
const TRUNK_B = '炮二平五 馬8進7 傌二進三 馬2進3 車一平二 車9平8 兵七進一 卒7進1 車二進六 炮8平9 車二平三 炮9退1';

// Chú giải theo nước (ply 1 = nước đầu của Đỏ). Dùng chung cho các biến cùng thân.
const NOTE_COMMON = {
  1: 'Pháo đầu (中炮): Đỏ đưa Pháo vào cột giữa, nhắm thẳng vào Tốt giữa và cung Tướng Đen. Đây là khai cuộc phổ biến nhất của bên đi trước.',
  2: 'Mã 8 tiến 7: vừa ra quân vừa bảo vệ Tốt giữa trước đòn Pháo đầu. Bình phong mã bắt đầu từ nước này.',
  3: 'Đỏ ra Mã bên phải (傌二進三) để bảo vệ Tốt giữa của mình và mở đường cho Xe.',
};
const NOTE_A = Object.assign({}, NOTE_COMMON, {
  4: 'Đen ra Xe sớm (車9平8): đưa quân mạnh nhất vào cuộc, nhắm cột 8.',
  5: 'Đỏ ra Xe (車一平二), chuẩn bị ép Xe qua sông.',
  6: 'Đen đẩy Tốt 7 (挺7卒): mở đường cho Mã 7, chủ động lo chuyện đổi Tốt và không để Xe đỏ tuần hà tự do.',
  7: 'Xe qua sông (車二進六): Đỏ ép lên sớm để chiếm đường tấn công trước khi Đen kịp bình Pháo.',
  8: 'Mã 2 tiến 3: hoàn tất "bình phong". Hai Mã đứng trước Tốt 3 và Tốt 7, che cung Tướng và bảo vệ nhau.',
  9: 'Đỏ tiến Tốt 7 (兵七進一): mở đường cho Mã phải và tạo thế tấn công ở cánh phải.',
  10: 'Bình Pháo đổi Xe (平炮兌車): Đen bình Pháo 8 sang 9 để mở cột 8 cho Xe Đen, đề nghị đổi Xe với Xe đỏ.',
  11: 'Đỏ không đổi Xe mà bình sang cột 3 (車二平三), ép vào Mã 7 và Tốt 7 từ phía sau.',
  12: 'Đen lùi Pháo 9 một bước (炮9退1): rút khỏi thế bị kẹp ở biên và chuẩn bị bình Pháo sang cột 7 để đuổi Xe đỏ.',
});
const NOTE_B = Object.assign({}, NOTE_COMMON, {
  4: 'Đen ra Mã trái trước (馬2進3): hoàn tất bình phong trước, Xe ra sau. Thứ tự nước đi khác nhưng cùng một cấu hình.',
  5: 'Đỏ ra Xe (車一平二).',
  6: 'Đen ra Xe (車9平8), đủ ba quân Mã, Mã, Xe.',
  7: 'Đỏ tiến Tốt 7 (兵七進一), chuẩn bị Xe qua sông.',
  8: 'Đen đẩy Tốt 7 (卒7進1): đón Tốt đỏ và mở đường cho Mã 7.',
  9: 'Xe qua sông (車二進六).',
  10: 'Bình Pháo đổi Xe (炮8平9): mở cột 8 cho Xe Đen.',
  11: 'Đỏ bình Xe sang cột 3 (車二平三) thay vì đổi Xe.',
  12: 'Đen lùi Pháo 9 (炮9退1). Từ đây hai thứ tự nước đi hội tụ về cùng một thế.',
});

const LINES = [
  {
    id: 'a1', title: 'Bình pháo đổi Xe – Ngũ cửu pháo, Mã đỏ về tâm',
    summary: 'Biến chính phổ biến: Đỏ dùng bộ Ngũ cửu pháo, hai bên đánh mỗi bên một cánh.',
    moves: TRUNK_A + ' 傌八進七 士4進5 炮八平九 車1平2 車九平八 炮9平7 車三平四 馬7進8 傌三退五 卒7進1 車四退一 卒7進1 車八進六 象7進5 傌七進六 馬8進9 相三進一 炮7平8 炮五平二 炮8平9 炮二平六 車8進5',
    notes: Object.assign({}, NOTE_A, {
      13: 'Đỏ ra Mã trái (傌八進七), đủ bộ quân chủ lực.',
      14: 'Đen lên Sĩ (士4進5): củng cố cung Tướng trước khi giao chiến.',
      15: 'Đỏ bình Pháo 8 sang 9 (炮八平九): dựng thế Ngũ cửu pháo (Pháo giữa + Pháo biên) và giải phóng Xe.',
      16: 'Đen đưa nốt Xe còn lại ra (車1平2).',
      17: 'Đỏ ra Xe (車九平八), nhắm cột 8.',
      18: 'Đen bình Pháo sang cột 7: dùng chính Mã 7 làm ngòi để nhắm vào Xe đỏ, buộc Xe phải rời chỗ.',
      19: 'Xe đỏ né sang cột 4 (車三平四).',
      20: 'Mã 7 tiến 8: nhân lúc Xe đỏ lùi, Mã Đen vọt ra tấn công cánh trái Đỏ.',
      21: 'Mã đỏ lùi về tâm (傌三退五): giảm áp lực ở cột 7 và tạo đường ra cho Mã còn lại. Đây là nước gần đây thịnh hành.',
      22: 'Tốt 7 qua sông (卒7進1): Đen bắt đầu phản công ở cột 7.',
    }),
  },
  {
    id: 'a2', title: 'Bình pháo đổi Xe – Ngũ cửu pháo, Xe trái qua sông',
    summary: 'Đảo thứ tự nước đi; Đỏ bình Pháo biên, sau đó Xe trái qua sông.',
    moves: TRUNK_B + ' 傌八進七 士4進5 炮八平九 炮9平7 車三平四 馬7進8 車九平八 車1平2 車八進六',
    notes: Object.assign({}, NOTE_B, {
      13: 'Đỏ ra Mã trái (傌八進七).',
      14: 'Đen lên Sĩ (士4進5).',
      15: 'Đỏ bình Pháo sang cột 9 (炮八平九): Ngũ cửu pháo.',
      16: 'Đen bình Pháo sang cột 7 (炮9平7), nhắm vào Xe đỏ qua ngòi là Mã 7.',
      17: 'Xe đỏ né sang cột 4 (車三平四).',
      18: 'Mã 7 tiến 8 (馬7進8).',
      19: 'Đỏ ra Xe trái (車九平八).',
      20: 'Đen ra Xe (車1平2), hai Xe đều đã tham chiến.',
      21: 'Xe đỏ qua sông (車八進六): hai bên bước vào giai đoạn giao tranh.',
    }),
  },
  {
    id: 'a3', title: 'Xe đỏ ép Pháo – Đen đánh Tốt 3',
    summary: 'Đỏ bình Xe bắt Pháo; Đen phản công bằng cách ăn Tốt 3.',
    moves: TRUNK_B + ' 傌八進七 炮9平7 車三平四 士4進5 炮八平九 馬7進8 車九平八 車1平2 車四進二 炮7進5 相三進一 炮2進4 兵五進一 炮7平3 傌三進四',
    notes: Object.assign({}, NOTE_B, {
      13: 'Đỏ ra Mã trái (傌八進七).',
      14: 'Đen bình Pháo 7 ngay (炮9平7): Pháo Đen nhắm vào Xe đỏ qua ngòi là Mã 7.',
      15: 'Xe đỏ né sang cột 4 (車三平四).',
      16: 'Đen lên Sĩ (士4進5).',
      21: 'Xe đỏ tiến 2 (車四進二): ép lên bắt Pháo 7.',
      22: 'Đen đáp bằng Pháo 7 tiến 5 (炮7進5), ăn Tốt 3 của Đỏ để giành thế phản công.',
    }),
  },
  {
    id: 'a4', title: 'Xe đỏ ép Pháo – Đen lùi Pháo 2',
    summary: 'Cùng thế Xe ép Pháo nhưng Đen chọn lùi Pháo 2 để hóa giải.',
    moves: TRUNK_B + ' 傌八進七 炮9平7 車三平四 士4進5 炮八平九 馬7進8 車九平八 車1平2 車四進二 炮2退1 車四退三 象3進5 車八進七 馬8進7 車四退二 炮7進1 傌七進六',
    notes: Object.assign({}, NOTE_B, {
      13: 'Đỏ ra Mã trái (傌八進七).',
      14: 'Đen bình Pháo 7 (炮9平7).',
      15: 'Xe đỏ né sang cột 4 (車三平四).',
      16: 'Đen lên Sĩ (士4進5).',
      21: 'Xe đỏ tiến 2 (車四進二).',
      22: 'Đen lùi Pháo 2 một bước (炮2退1), chọn thế vững thay vì ăn Tốt.',
    }),
  },
  {
    id: 'a5', title: 'Xe đỏ ép Pháo – Đen lùi Pháo 2, Pháo đỏ đánh biên',
    summary: 'Nhánh phụ của biến trước: Đỏ chọn Pháo tiến 4 thay vì Mã tiến 6.',
    moves: TRUNK_B + ' 傌八進七 炮9平7 車三平四 士4進5 炮八平九 馬7進8 車九平八 車1平2 車四進二 炮2退1 車四退三 象3進5 車八進七 馬8進7 車四退二 炮7進1 炮九進四',
    notes: Object.assign({}, NOTE_B, {
      13: 'Đỏ ra Mã trái (傌八進七).',
      14: 'Đen bình Pháo 7 (炮9平7).',
      15: 'Xe đỏ né sang cột 4 (車三平四).',
      16: 'Đen lên Sĩ (士4進5).',
      21: 'Xe đỏ tiến 2 (車四進二).',
      22: 'Đen lùi Pháo 2 (炮2退1).',
    }),
  },
  {
    id: 'b1', title: 'Đỏ xông Tốt giữa – Mã 3 lùi về tâm',
    summary: 'Đỏ tiến Tốt giữa gấp; Đen lùi Mã về tâm giữ vững trung lộ.',
    moves: TRUNK_A + ' 兵五進一 馬3退5 炮八進四',
    notes: Object.assign({}, NOTE_A, {
      13: 'Đỏ tiến Tốt giữa gấp (兵五進一): muốn đột phá trung lộ trước khi Đen hoàn chỉnh thế trận.',
      14: 'Đen lùi Mã 3 về cột 5 (馬3退5): Mã về giữ vững trung lộ và bảo vệ cung Tướng. Đây là cách đối phó được dùng trong thực chiến.',
      15: 'Đỏ tiến Pháo trái 4 (炮八進四): một trong các nước được xem là chủ yếu của Đỏ. Chi tiết các nhánh sau đó cần tra thêm tài liệu hoặc engine.',
    }),
  },
];

const OVERVIEW = [
  'Bình phong mã (屏風馬): Đen nhảy cả hai Mã lên cột 3 và cột 7, đứng ngay trước Tốt 3 và Tốt 7. Hai Mã che chắn cung Tướng, bảo vệ lẫn nhau và bảo vệ Tốt giữa.',
  'Đây là cách đối phó Pháo đầu (中炮) vững chắc và phổ biến nhất của bên Đen. Hai Pháo của Đen tạm giữ nguyên ở nhà để dùng sau.',
  'Kế hoạch của Đen: (1) ra quân nhanh, đủ Mã, Xe; (2) đẩy Tốt 7 để đổi Tốt và mở đường cho Mã; (3) bình Pháo sang biên hoặc bình Pháo 7 để đổi Xe hoặc đuổi Xe đỏ; (4) giữ trung lộ chắc chắn trước các đòn Xe qua sông và Tốt giữa tiến.',
  'Điểm cần cảnh giác: Xe đỏ qua sông ép vào Mã, Tốt giữa tiến mạnh (兵五進一), Pháo đỏ bắn qua ngòi lên Mã 7. Luôn kiểm tra quân nào đang được bảo vệ trước khi đi tiếp.',
];

module.exports = { LINES, OVERVIEW };
